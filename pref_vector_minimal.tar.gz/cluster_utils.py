"""
Utilities for running on MIT cluster with optimal performance.
"""

import os
import torch
from pathlib import Path

def setup_cluster_environment():
    """Configure environment for optimal cluster performance."""
    
    # Detect if we're on a cluster
    is_cluster = any([
        os.path.exists('/nfs'),
        'SLURM_JOB_ID' in os.environ,
        'SLURM_PROCID' in os.environ
    ])
    
    if is_cluster:
        print("🖥️  Cluster environment detected")
        
        # Set optimal thread counts
        os.environ['OMP_NUM_THREADS'] = '8'
        os.environ['MKL_NUM_THREADS'] = '8'
        os.environ['TOKENIZERS_PARALLELISM'] = 'false'
        
        # Set cache directories to tmp for better performance
        user = os.environ.get('USER', 'unknown')
        os.environ['TRANSFORMERS_CACHE'] = f'/tmp/{user}_transformers_cache'
        os.environ['HF_HOME'] = f'/tmp/{user}_hf_cache'
        os.environ['TORCH_HOME'] = f'/tmp/{user}_torch_cache'
        
        # Create cache directories
        for cache_dir in [os.environ['TRANSFORMERS_CACHE'], 
                         os.environ['HF_HOME'], 
                         os.environ['TORCH_HOME']]:
            Path(cache_dir).mkdir(parents=True, exist_ok=True)
        
        print(f"✓ Cache directories set up in /tmp/{user}_*")
        
        # GPU optimization
        if torch.cuda.is_available():
            print(f"✓ CUDA available: {torch.cuda.device_count()} GPU(s)")
            # Enable memory optimization
            torch.backends.cudnn.benchmark = True
        else:
            print("⚠️  No CUDA available, using CPU")
    
    return is_cluster

def get_cluster_model_config(model_name):
    """Get optimized model configuration for cluster."""
    
    config = {
        'device_map': 'auto',
        'torch_dtype': torch.float16,
        'low_cpu_mem_usage': True,
        'trust_remote_code': True
    }
    
    # Check available GPU memory
    if torch.cuda.is_available():
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1e9
        print(f"🔍 GPU Memory: {gpu_memory:.1f} GB")
        
        if gpu_memory < 20:  # Less than 20GB, use aggressive optimization
            config.update({
                'load_in_8bit': True,
                'device_map': 'auto',
                'max_memory': {0: '18GB', 'cpu': '30GB'}
            })
            print("🔧 Using 8-bit quantization for memory efficiency")
        elif gpu_memory < 40:  # 20-40GB
            config.update({
                'max_memory': {0: f'{int(gpu_memory * 0.9)}GB', 'cpu': '30GB'}
            })
    else:
        # CPU-only configuration
        config.update({
            'device_map': 'cpu',
            'torch_dtype': torch.float32,
            'low_cpu_mem_usage': True
        })
    
    return config

def setup_huggingface_auth():
    """Handle HuggingFace authentication on cluster."""
    
    # Check for token in standard locations
    token_locations = [
        Path.home() / '.cache' / 'huggingface' / 'token',
        Path.home() / '.huggingface' / 'token',
        Path('/tmp') / f"{os.environ.get('USER', 'unknown')}_hf_token"
    ]
    
    for token_file in token_locations:
        if token_file.exists():
            print(f"✓ Found HuggingFace token at {token_file}")
            return True
    
    # Check environment variable
    if 'HF_TOKEN' in os.environ:
        print("✓ Using HuggingFace token from environment variable")
        return True
    
    print("⚠️  No HuggingFace token found. Some models may not be accessible.")
    print("💡 Set token with: export HF_TOKEN='your_token_here'")
    return False

def log_cluster_info():
    """Log important cluster information for debugging."""
    
    print("=== Cluster Environment Info ===")
    print(f"Job ID: {os.environ.get('SLURM_JOB_ID', 'Not set')}")
    print(f"Node: {os.environ.get('SLURM_NODELIST', 'Unknown')}")
    print(f"CPUs: {os.environ.get('SLURM_CPUS_PER_TASK', 'Unknown')}")
    print(f"Memory: {os.environ.get('SLURM_MEM_PER_NODE', 'Unknown')}")
    print(f"GPU: {os.environ.get('SLURM_GPUS', 'None')}")
    print(f"Working dir: {os.getcwd()}")
    print(f"Python: {os.sys.executable}")
    
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            print(f"GPU {i}: {props.name} ({props.total_memory / 1e9:.1f} GB)")
    
    print("================================")

if __name__ == "__main__":
    # Test cluster setup
    setup_cluster_environment()
    setup_huggingface_auth()
    log_cluster_info()