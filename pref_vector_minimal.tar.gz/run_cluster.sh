#!/bin/bash
#SBATCH --job-name=pref_vector_transfer
#SBATCH -p sched_mit_mki_r8
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=12:00:00
#SBATCH --output=logs/slurm_%j.out
#SBATCH --error=logs/slurm_%j.err

# Load modules (adjust if your cluster uses different module names)
module load python/3.9
module load cuda/11.8

# Set up environment variables
export TRANSFORMERS_CACHE="/tmp/${USER}_transformers_cache"
export HF_HOME="/tmp/${USER}_hf_cache"
export TORCH_HOME="/tmp/${USER}_torch_cache"

# Create necessary directories
mkdir -p logs
mkdir -p results
mkdir -p ${TRANSFORMERS_CACHE}
mkdir -p ${HF_HOME}
mkdir -p ${TORCH_HOME}

# Navigate to project directory
cd /home/davidct/pref_vector

# Install dependencies in user space
pip install --user torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install --user transformers>=4.35.0
pip install --user datasets
pip install --user accelerate
pip install --user rouge-score
pip install --user nltk
pip install --user scikit-learn
pip install --user matplotlib
pip install --user seaborn
pip install --user pandas
pip install --user numpy
pip install --user tqdm

# Download NLTK data to avoid SSL issues
python -c "
import nltk
import ssl
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context
nltk.download('punkt', download_dir='/tmp/${USER}_nltk_data')
nltk.download('stopwords', download_dir='/tmp/${USER}_nltk_data')
"

# Set NLTK data path
export NLTK_DATA="/tmp/${USER}_nltk_data"

# Print system info
echo "=== System Information ==="
echo "CUDA available: $(python -c 'import torch; print(torch.cuda.is_available())')"
echo "GPU count: $(python -c 'import torch; print(torch.cuda.device_count())')"
echo "Python path: $(which python)"
echo "Working directory: $(pwd)"
echo "=========================="

# Run the experiment
echo "Starting preference vector transfer experiment..."
python run_experiment.py --full \
    --output-dir "results/cluster_exp_$(date +%Y%m%d_%H%M%S)" \
    --num-pairs 20 \
    --eval-samples 10

echo "Experiment completed!"
echo "Results saved in: results/cluster_exp_$(date +%Y%m%d_%H%M%S)"