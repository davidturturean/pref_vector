
# Cluster-specific configuration
import os

# Memory-efficient settings for cluster
CLUSTER_CONFIG = {
    'batch_size': 1,
    'max_memory_per_gpu': '22GB',
    'offload_to_cpu': True,
    'low_memory_mode': True,
    'gradient_checkpointing': True,
    'mixed_precision': True,
}

# Set environment variables for optimal cluster performance
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
os.environ['OMP_NUM_THREADS'] = '8'
os.environ['MKL_NUM_THREADS'] = '8'
