#!/usr/bin/env python3
"""
Setup script for MIT cluster environment.
Handles HuggingFace authentication and environment configuration.
"""

import os
import sys
from pathlib import Path

def setup_huggingface_auth():
    """Setup HuggingFace authentication."""
    print("=== HuggingFace Authentication Setup ===")
    
    # Check if token already exists
    hf_token_file = Path.home() / ".cache" / "huggingface" / "token"
    if hf_token_file.exists():
        print("✓ HuggingFace token already configured")
        return True
    
    # Prompt for token
    print("\nTo access HuggingFace models, you need to provide your access token.")
    print("Get your token from: https://huggingface.co/settings/tokens")
    print("Make sure it has 'Read' permissions for model repositories.")
    
    token = input("\nEnter your HuggingFace token (will be hidden): ").strip()
    
    if not token:
        print("❌ No token provided. Some models may not be accessible.")
        return False
    
    # Create directory and save token
    hf_token_file.parent.mkdir(parents=True, exist_ok=True)
    with open(hf_token_file, 'w') as f:
        f.write(token)
    
    # Set permissions (readable only by user)
    os.chmod(hf_token_file, 0o600)
    
    print("✓ HuggingFace token saved successfully")
    return True

def setup_cluster_config():
    """Create cluster-specific configuration."""
    print("\n=== Cluster Configuration Setup ===")
    
    # Create cluster config file
    cluster_config = """
# Cluster-specific configuration
import os

# Memory-efficient settings for cluster
CLUSTER_CONFIG = {
    'batch_size': 1,
    'max_memory_per_gpu': '22GB',
    'offload_to_cpu': True,
    'low_memory_mode': True,
    'gradient_checkpointing': True,
    'mixed_precision': True,
}

# Set environment variables for optimal cluster performance
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
os.environ['OMP_NUM_THREADS'] = '8'
os.environ['MKL_NUM_THREADS'] = '8'
"""
    
    with open('cluster_config.py', 'w') as f:
        f.write(cluster_config)
    
    print("✓ Cluster configuration created")

def create_slurm_submit_script():
    """Create easy submission script."""
    submit_script = """#!/bin/bash
# Quick submission script for MIT cluster

# Check if project directory is specified
if [ -z "$1" ]; then
    echo "Usage: $0 <project_directory_on_cluster>"
    echo "Example: $0 /nfs/home2/davidct/pref_vector"
    exit 1
fi

PROJECT_DIR="$1"

# Update the run_cluster.sh with correct path
sed -i "s|cd /nfs/home2/davidct/pref_vector|cd $PROJECT_DIR|" run_cluster.sh

# Submit job
echo "Submitting job to cluster..."
echo "Project directory: $PROJECT_DIR"
sbatch run_cluster.sh

echo "Job submitted! Check status with: squeue -u $USER"
echo "Monitor logs with: tail -f logs/slurm_*.out"
"""
    
    with open('submit_job.sh', 'w') as f:
        f.write(submit_script)
    
    os.chmod('submit_job.sh', 0o755)
    print("✓ Job submission script created")

def setup_requirements():
    """Create cluster-specific requirements."""
    requirements = """# Core ML libraries
torch>=2.0.0
transformers>=4.35.0
datasets>=2.14.0
accelerate>=0.24.0

# Evaluation and metrics
rouge-score>=0.1.2
nltk>=3.8
scikit-learn>=1.3.0

# Visualization and analysis
matplotlib>=3.7.0
seaborn>=0.12.0
pandas>=2.0.0
numpy>=1.24.0

# Utilities
tqdm>=4.66.0
huggingface_hub>=0.17.0

# Optional: for better performance
flash-attn>=2.3.0  # May need special installation
"""
    
    with open('requirements_cluster.txt', 'w') as f:
        f.write(requirements)
    
    print("✓ Cluster requirements file created")

def main():
    """Main setup function."""
    print("Setting up preference vector project for MIT cluster...")
    
    try:
        # Setup HuggingFace authentication
        setup_huggingface_auth()
        
        # Create cluster configuration
        setup_cluster_config()
        
        # Create submission scripts
        create_slurm_submit_script()
        
        # Create requirements file
        setup_requirements()
        
        print("\n=== Setup Complete! ===")
        print("\nNext steps:")
        print("1. Copy your project to the cluster:")
        print("   scp -r . username@cluster:/nfs/home2/davidct/pref_vector/")
        print("\n2. On the cluster, run:")
        print("   cd /nfs/home2/davidct/pref_vector")
        print("   python setup_cluster.py  # Run this script on cluster too")
        print("   ./submit_job.sh /nfs/home2/davidct/pref_vector")
        print("\n3. Monitor your job:")
        print("   squeue -u $USER")
        print("   tail -f logs/slurm_*.out")
        
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()