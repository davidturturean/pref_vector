import torch
import os
from dataclasses import dataclass
from typing import List, Optional

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not installed, skip

@dataclass
class ModelConfig:
    """Configuration for model loading and inference."""
    model_name: str
    cache_dir: Optional[str] = None
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    torch_dtype: torch.dtype = torch.float16
    max_length: int = 512
    temperature: float = 0.7
    top_p: float = 0.9
    do_sample: bool = True

def get_model_config(model_name: str, **overrides) -> ModelConfig:
    """Create a ModelConfig instance for a specific model with smart defaults."""
    base_config = {
        "model_name": model_name,
        "cache_dir": None,
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "torch_dtype": torch.float16,
        "max_length": 512,
        "temperature": 0.7,
        "top_p": 0.9,
        "do_sample": True
    }
    
    # Model-specific optimizations
    model_lower = model_name.lower()
    
    # Large models - use more aggressive memory optimization
    if any(size in model_lower for size in ["70b", "72b", "67b", "34b"]):
        base_config["torch_dtype"] = torch.float16  # Keep FP16 for large models
        base_config["max_length"] = 256  # Shorter sequences to save memory
    
    # Small models - can afford higher precision
    elif any(size in model_lower for size in ["0.5b", "2b", "small", "medium"]):
        base_config["torch_dtype"] = torch.float32  # Higher precision for small models
        base_config["max_length"] = 1024  # Longer sequences OK
    
    # MoE models - special handling
    elif "mixtral" in model_lower or "moe" in model_lower:
        base_config["torch_dtype"] = torch.float16  # Memory efficient for MoE
        base_config["max_length"] = 256
    
    # CPU-only models
    if not torch.cuda.is_available():
        base_config["torch_dtype"] = torch.float32  # CPU works better with FP32
        base_config["device"] = "cpu"
    
    # Apply any user overrides
    base_config.update(overrides)
    
    return ModelConfig(**base_config)

@dataclass
class ExperimentConfig:
    """Configuration for preference vector experiments."""
    source_model: str = "mistralai/Mistral-7B-v0.1"
    target_models: List[str] = None
    intervention_strategy: str = "functional_mapping"  # "layer_index", "functional_mapping", "adaptive"
    extraction_points: List[str] = None  # Functional extraction points
    vector_dim: int = 4096  # Hidden dimension for 7B models
    num_training_pairs: int = 100
    num_eval_samples: int = 50
    learning_rate: float = 1e-3
    num_epochs: int = 10
    batch_size: int = 1  # Due to memory constraints with large models
    
    # Cluster-specific settings
    use_cluster_optimizations: bool = False
    low_memory_mode: bool = False
    offload_to_cpu: bool = False
    
    # Architecture-aware settings
    enable_architecture_analysis: bool = True
    adaptation_strategy: str = "auto"  # "auto", "linear", "bottleneck", "residual", "multi_scale"
    dimension_adaptation: bool = True
    cross_architecture_compatibility_threshold: float = 0.5
    
    def __post_init__(self):
        if self.target_models is None:
            self.target_models = [
                "google/gemma-7b",
                "meta-llama/Llama-2-7b-hf"
            ]
        if self.extraction_points is None:
            self.extraction_points = [
                "feature_extraction", 
                "representation", 
                "decision_making"
            ]

@dataclass
class DataConfig:
    """Configuration for data generation and processing."""
    dataset_name: str = "cnn_dailymail"
    dataset_version: str = "3.0.0"
    max_input_length: int = 1024
    min_summary_length: int = 20
    max_summary_length: int = 200
    concise_target_length: int = 50
    verbose_target_length: int = 150
    seed: int = 42

# Global configurations
EXPERIMENT_CONFIG = ExperimentConfig()
DATA_CONFIG = DataConfig()