import torch
import json
import os
import numpy as np
from datetime import datetime
from typing import List, Dict, Tuple, Optional, Union
import logging
from tqdm import tqdm
from dataclasses import dataclass, asdict
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

from .config import EXPERIMENT_CONFIG, get_model_config, DATA_CONFIG
from .data_preparation import create_preference_dataset, SummaryPair
from .vector_extraction import extract_verbosity_vector, PreferenceVectorExtractor
from .vector_injection import SteerableModel, CrossModelTransferer, create_test_prompts
from .evaluation_metrics import PreferenceVectorEvaluator
from .linear_adapter import AdapterTrainer, AdapterLibrary, train_cross_model_adapter

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ExperimentResults:
    """Container for complete experiment results."""
    experiment_id: str
    timestamp: str
    config: Dict
    source_model: str
    target_models: List[str]
    preference_vector_info: Dict
    direct_transfer_results: Dict
    adapter_results: Dict
    evaluation_summary: Dict
    conclusions: Dict

class ExperimentPipeline:
    """Orchestrates the complete preference vector transfer experiment."""
    
    def __init__(self, experiment_config: EXPERIMENT_CONFIG = EXPERIMENT_CONFIG):
        self.config = experiment_config
        self.experiment_id = f"pref_vector_exp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.results_dir = f"results/{self.experiment_id}"
        os.makedirs(self.results_dir, exist_ok=True)
        
        self.evaluator = PreferenceVectorEvaluator()
        self.transferer = CrossModelTransferer()
        self.adapter_library = AdapterLibrary()
        
        # Experiment state
        self.summary_pairs = None
        self.preference_vector = None
        self.source_model = None
        
        logger.info(f"Initialized experiment pipeline: {self.experiment_id}")
    
    def run_complete_experiment(self, save_results: bool = True) -> ExperimentResults:
        """Run the complete preference vector transfer experiment."""
        logger.info("Starting complete preference vector transfer experiment")
        
        results = ExperimentResults(
            experiment_id=self.experiment_id,
            timestamp=datetime.now().isoformat(),
            config=asdict(self.config),
            source_model=self.config.source_model,
            target_models=self.config.target_models,
            preference_vector_info={},
            direct_transfer_results={},
            adapter_results={},
            evaluation_summary={},
            conclusions={}
        )
        
        try:
            # Phase 1: Data preparation
            logger.info("Phase 1: Preparing summary pair dataset")
            self.summary_pairs = self._prepare_dataset()
            
            # Phase 2: Extract preference vector
            logger.info("Phase 2: Extracting preference vector from source model")
            self.preference_vector = self._extract_preference_vector()
            results.preference_vector_info = self._analyze_preference_vector()
            
            # Phase 3: Validate on source model
            logger.info("Phase 3: Validating preference vector on source model")
            source_validation = self._validate_source_model()
            
            # Phase 4: Test direct transfer
            logger.info("Phase 4: Testing direct transfer to target models")
            results.direct_transfer_results = self._test_direct_transfer()
            
            # Phase 5: Train and test adapters
            logger.info("Phase 5: Training linear adapters for failed transfers")
            results.adapter_results = self._test_adapter_transfer()
            
            # Phase 6: Comprehensive evaluation
            logger.info("Phase 6: Comprehensive evaluation and analysis")
            results.evaluation_summary = self._comprehensive_evaluation(
                source_validation, results.direct_transfer_results, results.adapter_results
            )
            
            # Phase 7: Draw conclusions
            results.conclusions = self._draw_conclusions(results)
            
            if save_results:
                self._save_results(results)
            
            logger.info("Experiment completed successfully")
            return results
            
        except Exception as e:
            logger.error(f"Experiment failed: {e}")
            results.conclusions = {"error": str(e)}
            if save_results:
                self._save_results(results)
            raise
    
    def _prepare_dataset(self) -> List[SummaryPair]:
        """Prepare the summary pair dataset."""
        dataset_path = os.path.join(self.results_dir, "summary_pairs")
        
        pairs = create_preference_dataset(
            num_pairs=self.config.num_training_pairs,
            save_path=dataset_path
        )
        
        logger.info(f"Prepared {len(pairs)} summary pairs")
        return pairs
    
    def _extract_preference_vector(self) -> torch.Tensor:
        """Extract preference vector from source model."""
        vector_path = os.path.join(self.results_dir, "preference_vector.json")
        
        vector = extract_verbosity_vector(
            model_name=self.config.source_model,
            summary_pairs=self.summary_pairs,
            method="difference",
            save_path=vector_path
        )
        
        logger.info(f"Extracted preference vector with shape {vector.shape}")
        return vector
    
    def _analyze_preference_vector(self) -> Dict:
        """Analyze the extracted preference vector."""
        analysis = {
            'shape': list(self.preference_vector.shape),
            'norm': self.preference_vector.norm().item(),
            'mean': self.preference_vector.mean().item(),
            'std': self.preference_vector.std().item(),
            'sparsity': (self.preference_vector.abs() < 1e-6).float().mean().item(),
            'max_magnitude': self.preference_vector.abs().max().item()
        }
        
        return analysis
    
    def _validate_source_model(self) -> Dict:
        """Validate preference vector on the source model."""
        if self.source_model is None:
            self.source_model = SteerableModel(self.config.source_model)
        
        test_prompts = create_test_prompts()[:self.config.num_eval_samples]
        
        validation_results = {}
        for i, prompt in enumerate(test_prompts):
            try:
                generations = self.source_model.compare_generations(
                    prompt,
                    self.preference_vector,
                    self.config.intervention_layer,
                    scales=[-1.0, 0.0, 1.0]
                )
                
                # Evaluate the steering effect
                if 0.0 in generations and 1.0 in generations:
                    eval_result = self.evaluator.evaluate_single_generation(
                        prompt,
                        generations[0.0],
                        generations[1.0],
                        "verbose"
                    )
                    
                    validation_results[f"prompt_{i}"] = {
                        'prompt': prompt,
                        'generations': generations,
                        'evaluation_score': eval_result.overall_score,
                        'style_consistency': eval_result.style_metrics['overall_consistency']
                    }
                
            except Exception as e:
                logger.warning(f"Failed to validate prompt {i}: {e}")
                continue
        
        # Compute overall validation score
        if validation_results:
            scores = [r['evaluation_score'] for r in validation_results.values()]
            validation_summary = {
                'average_score': np.mean(scores),
                'std_score': np.std(scores),
                'num_successful': len(scores),
                'total_prompts': len(test_prompts)
            }
        else:
            validation_summary = {'average_score': 0.0, 'num_successful': 0}
        
        return {
            'detailed_results': validation_results,
            'summary': validation_summary
        }
    
    def _test_direct_transfer(self) -> Dict:
        """Test direct transfer of preference vector to target models."""
        test_prompts = create_test_prompts()[:self.config.num_eval_samples]
        
        transfer_results = self.transferer.test_multiple_models(
            self.preference_vector,
            self.config.target_models,
            test_prompts,
            self.config.intervention_layer
        )
        
        # Evaluate transfer results
        evaluation = self.evaluator.evaluate_experiment_results(
            transfer_results, "verbose"
        )
        
        return {
            'raw_results': transfer_results,
            'evaluation': evaluation
        }
    
    def _test_adapter_transfer(self) -> Dict:
        """Test adapter-based transfer for models where direct transfer failed."""
        adapter_results = {}
        
        # Create some reference vectors for adapter training
        reference_vectors = [
            self.preference_vector,
            self.preference_vector * 0.5,
            -self.preference_vector * 0.3
        ]
        
        test_prompts = create_test_prompts()[:10]
        
        for target_model_name in self.config.target_models:
            try:
                logger.info(f"Training adapter for {target_model_name}")
                
                adapter, evaluation = train_cross_model_adapter(
                    self.config.source_model,
                    target_model_name,
                    reference_vectors,
                    test_prompts,
                    self.config.intervention_layer
                )
                
                # Save the adapter
                adapter_path = self.adapter_library.save_adapter(
                    adapter,
                    self.config.source_model,
                    target_model_name,
                    {'experiment_id': self.experiment_id}
                )
                
                adapter_results[target_model_name] = {
                    'adapter_path': adapter_path,
                    'evaluation': evaluation,
                    'success': evaluation.get('average_score', 0) > 0.5
                }
                
            except Exception as e:
                logger.error(f"Failed to train adapter for {target_model_name}: {e}")
                adapter_results[target_model_name] = {
                    'error': str(e),
                    'success': False
                }
        
        return adapter_results
    
    def _comprehensive_evaluation(self, 
                                 source_validation: Dict,
                                 direct_results: Dict,
                                 adapter_results: Dict) -> Dict:
        """Perform comprehensive evaluation of all results."""
        evaluation_summary = {
            'source_model_validation': {
                'success': source_validation['summary']['average_score'] > 0.5,
                'score': source_validation['summary']['average_score']
            },
            'direct_transfer_success': {},
            'adapter_transfer_success': {},
            'overall_findings': {}
        }
        
        # Analyze direct transfer success
        direct_eval = direct_results.get('evaluation', {})
        for model_name in self.config.target_models:
            model_eval = direct_eval.get('model_evaluations', {}).get(model_name, {})
            success = model_eval.get('avg_score', 0) > 0.3
            evaluation_summary['direct_transfer_success'][model_name] = {
                'success': success,
                'score': model_eval.get('avg_score', 0)
            }
        
        # Analyze adapter transfer success
        for model_name, adapter_result in adapter_results.items():
            success = adapter_result.get('success', False)
            score = adapter_result.get('evaluation', {}).get('average_score', 0)
            evaluation_summary['adapter_transfer_success'][model_name] = {
                'success': success,
                'score': score
            }
        
        # Overall findings
        direct_successes = sum(1 for r in evaluation_summary['direct_transfer_success'].values() if r['success'])
        adapter_successes = sum(1 for r in evaluation_summary['adapter_transfer_success'].values() if r['success'])
        
        evaluation_summary['overall_findings'] = {
            'source_validation_passed': evaluation_summary['source_model_validation']['success'],
            'direct_transfer_success_rate': direct_successes / len(self.config.target_models),
            'adapter_transfer_success_rate': adapter_successes / len(self.config.target_models),
            'total_models_tested': len(self.config.target_models)
        }
        
        return evaluation_summary
    
    def _draw_conclusions(self, results: ExperimentResults) -> Dict:
        """Draw scientific conclusions from the experiment results."""
        conclusions = {
            'hypotheses_tested': [],
            'findings': [],
            'implications': [],
            'limitations': [],
            'future_work': []
        }
        
        eval_summary = results.evaluation_summary
        
        # Test hypothesis 1: Preference vectors can be extracted reliably
        if eval_summary['source_model_validation']['success']:
            conclusions['hypotheses_tested'].append({
                'hypothesis': 'Preference vectors can be reliably extracted and applied within the same model',
                'result': 'SUPPORTED',
                'evidence': f"Source validation score: {eval_summary['source_model_validation']['score']:.3f}"
            })
            conclusions['findings'].append("Preference vectors can effectively steer model behavior within the source model family")
        else:
            conclusions['hypotheses_tested'].append({
                'hypothesis': 'Preference vectors can be reliably extracted and applied within the same model',
                'result': 'NOT SUPPORTED',
                'evidence': f"Source validation failed with score: {eval_summary['source_model_validation']['score']:.3f}"
            })
        
        # Test hypothesis 2: Direct cross-model transfer works
        direct_success_rate = eval_summary['overall_findings']['direct_transfer_success_rate']
        if direct_success_rate > 0.5:
            conclusions['hypotheses_tested'].append({
                'hypothesis': 'Preference vectors transfer directly between different model architectures',
                'result': 'SUPPORTED',
                'evidence': f"Direct transfer success rate: {direct_success_rate:.2%}"
            })
            conclusions['findings'].append("Remarkable cross-model alignment exists for high-level preference dimensions")
            conclusions['implications'].append("Models may learn similar internal representations for abstract concepts")
        else:
            conclusions['hypotheses_tested'].append({
                'hypothesis': 'Preference vectors transfer directly between different model architectures',
                'result': 'NOT SUPPORTED',
                'evidence': f"Direct transfer success rate: {direct_success_rate:.2%}"
            })
            conclusions['findings'].append("Direct cross-model transfer is limited, suggesting model-specific representations")
        
        # Test hypothesis 3: Linear adapters can bridge the gap
        adapter_success_rate = eval_summary['overall_findings']['adapter_transfer_success_rate']
        if adapter_success_rate > direct_success_rate:
            conclusions['hypotheses_tested'].append({
                'hypothesis': 'Linear adapters can enable cross-model preference transfer',
                'result': 'SUPPORTED',
                'evidence': f"Adapter success rate ({adapter_success_rate:.2%}) > Direct rate ({direct_success_rate:.2%})"
            })
            conclusions['findings'].append("Linear transformations can partially align preference representations")
            conclusions['implications'].append("Model representations differ primarily by linear transformations")
        else:
            conclusions['hypotheses_tested'].append({
                'hypothesis': 'Linear adapters can enable cross-model preference transfer',
                'result': 'INCONCLUSIVE',
                'evidence': f"Adapter success rate: {adapter_success_rate:.2%}"
            })
        
        # Limitations
        conclusions['limitations'].extend([
            "Limited to summary generation task - may not generalize to other domains",
            "Small sample size may affect statistical significance",
            "Evaluation metrics are heuristic-based and may not capture all aspects of preference transfer",
            "Hardware constraints limited model size and variety"
        ])
        
        # Future work
        conclusions['future_work'].extend([
            "Test on larger variety of model architectures and sizes",
            "Explore non-linear adaptation methods",
            "Investigate transfer of multiple preference dimensions simultaneously",
            "Develop more sophisticated evaluation metrics",
            "Test on other behavioral dimensions beyond verbosity"
        ])
        
        return conclusions
    
    def _save_results(self, results: ExperimentResults):
        """Save experiment results to disk."""
        results_path = os.path.join(self.results_dir, "experiment_results.json")
        
        # Convert torch tensors to lists for JSON serialization
        def convert_tensors(obj):
            if isinstance(obj, torch.Tensor):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {k: convert_tensors(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_tensors(item) for item in obj]
            else:
                return obj
        
        serializable_results = convert_tensors(asdict(results))
        
        with open(results_path, 'w') as f:
            json.dump(serializable_results, f, indent=2)
        
        logger.info(f"Saved experiment results to {results_path}")
        
        # Also create a summary report
        self._generate_summary_report(results)
    
    def _generate_summary_report(self, results: ExperimentResults):
        """Generate a human-readable summary report."""
        report_path = os.path.join(self.results_dir, "summary_report.md")
        
        with open(report_path, 'w') as f:
            f.write(f"# Preference Vector Transfer Experiment Report\n\n")
            f.write(f"**Experiment ID:** {results.experiment_id}\n")
            f.write(f"**Timestamp:** {results.timestamp}\n\n")
            
            f.write(f"## Configuration\n")
            f.write(f"- **Source Model:** {results.source_model}\n")
            f.write(f"- **Target Models:** {', '.join(results.target_models)}\n")
            f.write(f"- **Intervention Layer:** {self.config.intervention_layer}\n")
            f.write(f"- **Training Pairs:** {self.config.num_training_pairs}\n\n")
            
            f.write(f"## Key Findings\n")
            for finding in results.conclusions.get('findings', []):
                f.write(f"- {finding}\n")
            f.write("\n")
            
            f.write(f"## Hypotheses Tested\n")
            for hypothesis in results.conclusions.get('hypotheses_tested', []):
                f.write(f"**{hypothesis['hypothesis']}**\n")
                f.write(f"- Result: {hypothesis['result']}\n")
                f.write(f"- Evidence: {hypothesis['evidence']}\n\n")
            
            f.write(f"## Implications\n")
            for implication in results.conclusions.get('implications', []):
                f.write(f"- {implication}\n")
            f.write("\n")
            
            f.write(f"## Limitations\n")
            for limitation in results.conclusions.get('limitations', []):
                f.write(f"- {limitation}\n")
        
        logger.info(f"Generated summary report: {report_path}")

def run_lightweight_experiment():
    """Run a lightweight version of the experiment for testing."""
    logger.info("Running lightweight experiment for demonstration")
    
    # Use smaller models and fewer samples
    lightweight_config = EXPERIMENT_CONFIG
    lightweight_config.source_model = "microsoft/DialoGPT-medium"
    lightweight_config.target_models = ["microsoft/DialoGPT-small"]
    lightweight_config.num_training_pairs = 5
    lightweight_config.num_eval_samples = 3
    lightweight_config.intervention_layer = 8
    
    pipeline = ExperimentPipeline(lightweight_config)
    
    try:
        results = pipeline.run_complete_experiment()
        print(f"Lightweight experiment completed: {results.experiment_id}")
        return results
    except Exception as e:
        logger.error(f"Lightweight experiment failed: {e}")
        return None

if __name__ == "__main__":
    # Run the lightweight experiment
    results = run_lightweight_experiment()
    if results:
        print("Experiment completed successfully!")
        print(f"Results saved in: results/{results.experiment_id}/")
    else:
        print("Experiment failed - check logs for details")