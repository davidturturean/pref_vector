import torch
import torch.nn as nn
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
from typing import List, Dict, Tuple, Optional, Callable
import logging
from tqdm import tqdm
from dataclasses import dataclass
import json
from datetime import datetime

from .config import get_model_config, EXPERIMENT_CONFIG
from .data_preparation import SummaryPair
from .utils import ModelLoader, HookManager, DeviceManager, LayerUtils, VectorUtils, handle_errors

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ActivationCache:
    """Cache for storing model activations during inference."""
    activations: Dict[str, torch.Tensor]
    layer_idx: int
    
    def __post_init__(self):
        if not self.activations:
            self.activations = {}

# Use shared HookManager instead of local ActivationHook
# This eliminates code duplication with vector_injection.py

class PreferenceVectorExtractor:
    """Extracts preference vectors from language models using activation differences."""
    
    def __init__(self, model_name: str, intervention_layer: int = None):
        self.model_name = model_name
        self.intervention_layer = intervention_layer or LayerUtils.get_default_intervention_layer(model_name)
        self.model = None
        self.tokenizer = None
        self.hook = None
        self._load_model()
    
    def _load_model(self):
        """Load the transformer model and tokenizer."""
        self.model, self.tokenizer = ModelLoader.load_model_and_tokenizer(self.model_name)
        self.hook = HookManager(self.intervention_layer)
    
    def _get_activations(self, text: str, max_length: int = 512) -> torch.Tensor:
        """Get hidden state activations for a given text."""
        inputs = self.tokenizer(
            text, 
            return_tensors="pt", 
            truncation=True, 
            max_length=max_length,
            padding=True
        )
        inputs = DeviceManager.to_device(inputs, DeviceManager.get_model_device(self.model))
        
        self.hook.register_hooks(self.model)
        
        try:
            with torch.no_grad():
                outputs = self.model(**inputs)
            
            activation = self.hook.get_residual_activation()
            
            if activation is None:
                if hasattr(outputs, 'hidden_states') and outputs.hidden_states:
                    activation = outputs.hidden_states[self.intervention_layer]
                else:
                    raise RuntimeError("Could not capture activations")
            
            sentence_activation = activation[:, -1, :].squeeze()
            return sentence_activation
        
        finally:
            self.hook.remove_hooks()
    
    def extract_preference_vector_from_pairs(self, 
                                           summary_pairs: List[SummaryPair],
                                           method: str = "difference") -> torch.Tensor:
        """Extract preference vector from summary pairs using activation differences."""
        logger.info(f"Extracting preference vector using {method} method from {len(summary_pairs)} pairs")
        
        if method == "difference":
            return self._extract_via_difference(summary_pairs)
        elif method == "contrastive":
            return self._extract_via_contrastive(summary_pairs)
        else:
            raise ValueError(f"Unknown extraction method: {method}")
    
    def _extract_via_difference(self, summary_pairs: List[SummaryPair]) -> torch.Tensor:
        """Extract preference vector by averaging activation differences."""
        differences = []
        
        for pair in tqdm(summary_pairs, desc="Computing activation differences"):
            try:
                # Get activations for both styles
                verbose_prompt = f"Provide a detailed summary: {pair.source_text[:500]}\n\nDetailed summary: {pair.verbose_summary}"
                concise_prompt = f"Provide a brief summary: {pair.source_text[:500]}\n\nBrief summary: {pair.concise_summary}"
                
                verbose_activation = self._get_activations(verbose_prompt)
                concise_activation = self._get_activations(concise_prompt)
                
                # Compute difference (verbose - concise)
                diff = verbose_activation - concise_activation
                differences.append(diff)
                
            except Exception as e:
                logger.warning(f"Failed to process pair: {e}")
                continue
        
        if not differences:
            raise RuntimeError("No valid activation differences computed")
        
        # Average all differences to get the preference vector
        preference_vector = torch.stack(differences).mean(dim=0)
        
        # Normalize the vector using shared utility
        preference_vector = VectorUtils.normalize_vector(preference_vector)
        
        logger.info(f"Extracted preference vector with shape {preference_vector.shape}")
        return preference_vector
    
    def _extract_via_contrastive(self, summary_pairs: List[SummaryPair]) -> torch.Tensor:
        """Extract preference vector using contrastive learning approach."""
        # This is a more sophisticated method that could be implemented
        # For now, falling back to difference method
        logger.warning("Contrastive method not implemented, using difference method")
        return self._extract_via_difference(summary_pairs)
    
    def extract_preference_vector_optimized(self, 
                                          summary_pairs: List[SummaryPair],
                                          learning_rate: float = 1e-3,
                                          num_epochs: int = 10) -> torch.Tensor:
        """Extract preference vector through gradient-based optimization."""
        logger.info(f"Training preference vector with {len(summary_pairs)} pairs")
        
        # Initialize preference vector
        vector_dim = self.model.config.hidden_size
        preference_vector = torch.randn(vector_dim, requires_grad=True, device=self.model.device)
        
        optimizer = torch.optim.Adam([preference_vector], lr=learning_rate)
        
        for epoch in range(num_epochs):
            total_loss = 0.0
            
            for pair in tqdm(summary_pairs, desc=f"Epoch {epoch+1}/{num_epochs}", leave=False):
                try:
                    optimizer.zero_grad()
                    
                    # Base prompt for summarization
                    base_prompt = f"Summarize the following text: {pair.source_text[:500]}\n\nSummary:"
                    
                    # Get base activations without steering
                    base_activation = self._get_activations(base_prompt)
                    
                    # Steer towards verbosity
                    steered_activation = base_activation + preference_vector
                    
                    # This is a simplified loss - in practice, you'd need to:
                    # 1. Generate text with steered activations
                    # 2. Compare with target verbose summary
                    # For now, we'll use a proxy loss based on activation magnitude
                    
                    # Loss: encourage the vector to create meaningful differences
                    loss = -torch.norm(preference_vector)  # Regularization term
                    
                    loss.backward()
                    optimizer.step()
                    
                    total_loss += loss.item()
                
                except Exception as e:
                    logger.warning(f"Failed to process pair in optimization: {e}")
                    continue
            
            avg_loss = total_loss / len(summary_pairs)
            logger.info(f"Epoch {epoch+1} average loss: {avg_loss:.4f}")
        
        # Normalize and detach the final vector using shared utility
        final_vector = VectorUtils.normalize_vector(preference_vector.detach())
        return final_vector
    
    def save_vector(self, vector: torch.Tensor, filepath: str, metadata: Dict = None):
        """Save preference vector to disk."""
        data = {
            'vector': vector.cpu().numpy().tolist(),
            'shape': list(vector.shape),
            'model_name': self.model_name,
            'intervention_layer': self.intervention_layer,
            'metadata': metadata or {}
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        logger.info(f"Saved preference vector to {filepath}")
    
    def load_vector(self, filepath: str) -> Tuple[torch.Tensor, Dict]:
        """Load preference vector from disk."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        vector = torch.tensor(data['vector'], dtype=torch.float32)
        metadata = data.get('metadata', {})
        
        logger.info(f"Loaded preference vector from {filepath}")
        return vector, metadata

def extract_preference_vector(model_name: str, 
                            summary_pairs: List[SummaryPair],
                            method: str = "difference",
                            trait: str = "verbosity",
                            save_path: str = None) -> torch.Tensor:
    """Main function to extract preference vector for any trait."""
    extractor = PreferenceVectorExtractor(model_name)
    
    if method == "optimized":
        vector = extractor.extract_preference_vector_optimized(summary_pairs)
    else:
        vector = extractor.extract_preference_vector_from_pairs(summary_pairs, method)
    
    if save_path:
        metadata = {
            'trait': trait,
            'method': method,
            'num_pairs': len(summary_pairs),
            'extraction_date': datetime.now().isoformat()
        }
        extractor.save_vector(vector, save_path, metadata)
    
    return vector

# Keep backward compatibility
def extract_verbosity_vector(model_name: str, 
                           summary_pairs: List[SummaryPair],
                           method: str = "difference",
                           save_path: str = None) -> torch.Tensor:
    """Backward compatibility wrapper for verbosity extraction."""
    return extract_preference_vector(model_name, summary_pairs, method, "verbosity", save_path)

if __name__ == "__main__":
    # Example usage
    from .data_preparation import create_preference_dataset
    
    # Generate sample data
    pairs = create_preference_dataset(num_pairs=10)
    
    # Extract preference vector
    model_name = "microsoft/DialoGPT-medium"  # Smaller model for testing
    vector = extract_verbosity_vector(
        model_name=model_name,
        summary_pairs=pairs,
        method="difference",
        save_path="preference_vector.json"
    )
    
    print(f"Extracted preference vector with shape: {vector.shape}")
    print(f"Vector norm: {vector.norm().item():.4f}")